
export interface ExposedLobbyPlayerInfo { id: number, username: number, }