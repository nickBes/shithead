
export type ClickedCardLocation = { location: "trash" } | { location: "myCards", card_index: number, };